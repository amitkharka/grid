import { useEffect } from 'react';
import type { RootState } from '../../redux/store/store';
import { Radio, DatePicker, RadioChangeEvent } from 'antd';
import { NoUndefinedRangeValueType } from 'rc-picker/lib/PickerInput/RangePicker';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router';
import { useSearchParams } from 'react-router';
import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import { setFilterType, setCurrency } from '../../redux/slices/headerSlice';

dayjs.extend(customParseFormat);

const DATE_FORMAT = 'YYYY-MM-DD';
const { RangePicker } = DatePicker;

const FILTER_OPTIONS = ["1W", "2W", "M"];
const CURRENCY_OPTIONS = ["USD", "Trans", "Local"];

const TableHeader = () => {
  const { filterType = FILTER_OPTIONS[0], currency = CURRENCY_OPTIONS[0], } = useSelector((state: RootState) => state.header);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const dispatch = useDispatch();
  const isCustomFilter = filterType.includes(",");


  const handleFilterChange = (event: RadioChangeEvent) => {
    dispatch(setFilterType(event.target.value));
  };

  const handleCurrencyChange = (event: RadioChangeEvent) => {
    dispatch(setCurrency(event.target.value));
  };

  const handleRangeChange = (dates: NoUndefinedRangeValueType<any> | null, dateStrings: [string, string]) => {
    const [from, to] = dateStrings;
    dispatch(setFilterType(`${from},${to}`));
  };

  useEffect(() => {
    if (filterType && currency) {
      const params = new URLSearchParams(searchParams);
      if (filterType) params.set('filter', filterType);
      if (currency) params.set('currency', currency);
      navigate(`?${params.toString()}`);
    }
  }, [filterType, currency]);

  useEffect(() => {
    if (searchParams.has('filter') && searchParams.has('currency')) {
      const filter = searchParams.get('filter')!;
      const currency = searchParams.get('currency')!;
      dispatch(setFilterType(filter));
      dispatch(setCurrency(currency));
    }
  }, []);


  return (
    <div className="flex flex-row mb-4">
      <div>
        <Radio.Group
          onChange={handleFilterChange}
          value={isCustomFilter ? "" : filterType}
        >
          {FILTER_OPTIONS.map((option) => (
            <Radio.Button key={option} value={option}>
              {option}
            </Radio.Button>
          ))}
        </Radio.Group>
        <RangePicker
          placeholder={["From", "To"]}
          className={`rounded-none ${isCustomFilter ? "border-[#1677ff]" : ""}`}
          // value={isCustomFilter ? [null, null] : filterType.split(",").map((date) => dayjs(date, DATE_FORMAT))}
          style={{ width: "150px" }} onChange={handleRangeChange}
        />
      </div>
      <div className='ml-4'>
        <Radio.Group
          onChange={handleCurrencyChange}
          value={currency}
        >
          {CURRENCY_OPTIONS.map((option) => (
            <Radio.Button key={option} value={option}>
              {option}
            </Radio.Button>
          ))}
        </Radio.Group>
      </div>
    </div>
  );
};

export default TableHeader;