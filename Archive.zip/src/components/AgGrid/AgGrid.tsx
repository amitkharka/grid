import {
  useCallback,
  useMemo,
  useRef,
  useState,
  useEffect,
} from "react";
import { AgGridReact } from "ag-grid-react";
import {
  ClientSideRowModelModule,
  ColDef,
  CsvExportModule,
  IDetailCellRendererParams,
  ModuleRegistry,
  NumberEditorModule,
  TextEditorModule,
  ValidationModule,
} from "ag-grid-community";
import { Button} from "antd";
ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  CsvExportModule,
  NumberEditorModule,
  TextEditorModule,
  ValidationModule
]);

const AgGrid = ({
  columns,
  rowData,
}) => {
  const [columnDefs, setColumnDefs] = useState<ColDef[]>([]);
  // const [rowData, setRowData] = useState<any[]>([]);

  const gridRef = useRef<AgGridReact>(null);

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      editable: false,
      resizable: false,
      minWidth: 100,
      flex: 1,
      cellClass: (param) => {
        if (param.column.colId === 'date') return 'font-semibold';
        return param.value > 0 ? 'text-center text-green-600' : 'text-center text-rose-500';
      },
    };
  }, []);

  const popupParent = useMemo<HTMLElement | null>(() => {
    return document.body || [];
  }, []);

  const onCsvExport = useCallback(() => {
    gridRef.current!.api.exportDataAsCsv();
  }, []);

  const onExcelExport = useCallback(() => {
    gridRef.current!.api.exportDataAsExcel();
  }, []);

  const detailCellRendererParams = useMemo<IDetailCellRendererParams>(() => {
    return {
    detailGridOptions: {
      columnDefs: [
        { field: "a2", headerName: "Column A2" },
        { field: "b2", headerName: "Column B2" },
      ],
      defaultColDef: {
        flex: 1,
      },
    },
    getDetailRowData: (params) => {
      // Provide children data for the nested table
      console.log("params", params);  
      params.successCallback(params.data.children);
    }
  } as IDetailCellRendererParams;
  }, []);


  useEffect(() => {
    if (columns.length) {
      const columnDefs = columns.map(({ headerName, field, filter, cellRender }) => {
        return {
          headerName,
          field,
          filter,
          cellRender
        };
      });
      setColumnDefs(columnDefs);
    }
  }, [columns]);

  const checkForNegativeValues = (data) => {
    return Object.values(data).some(
      (value) => typeof value === "number" && value < 0
    );
  };

  const processedRowData = useMemo(() => {
    return rowData.map((row) => ({
      ...row,
      hasNegativeValue: checkForNegativeValues(row),
    }));
  }, [rowData]);

  return (
    <div className="flex flex-col">
      <div className="flex flex-row justify-between mb-4">
        <h4 className="text-lg font-semibold text-gray-800">
          Unbalanced
        </h4>
        <div>
          <span className="font-semibold text-gray-800">Export to:</span>
          <Button className="ml-2 rounded-none" onClick={() => onCsvExport()}>
            CSV
          </Button>
          <Button className="ml-2 rounded-none" onClick={() => onExcelExport()}>
            Excel
          </Button>
        </div>
      </div>
      <div className="ag-theme-alpine h-[600px]">
          <AgGridReact
            ref={gridRef}
            rowData={processedRowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressExcelExport={true}
            popupParent={popupParent}
            groupDefaultExpanded={0}
            masterDetail={true}
            isRowMaster={(row) => !!row.children && row.children.length > 0}
            detailCellRendererParams={detailCellRendererParams}
          />
      </div>
    </div>
  );
};

export default AgGrid;
