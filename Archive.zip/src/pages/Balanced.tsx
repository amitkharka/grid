const Balanced = () => {
  return (
    <div>
      <h1>Balance</h1>
      <p>Balance is the key to life.</p>
    </div>
  );
};

export default Balanced;