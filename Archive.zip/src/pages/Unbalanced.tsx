import { useEffect, useState } from 'react'
import AgGrid from "../components/AgGrid/AgGrid";
import { useGetUnbalancedDataQuery } from '../services/unbalancedService';
import { useSelector } from 'react-redux';
import { RootState } from '../redux/store/store';

const UnBalanced = () => {
  const { filterType, currency } = useSelector((state: RootState) => state.header);
  const { data, error, isLoading } = useGetUnbalancedDataQuery({ date: filterType, crr: currency });
  const [columns, setColumns] = useState<string[]>([]);
  const [rowData, setRowData] = useState<any[]>([]);

  useEffect(() => {
    if (data?.length) {
      const columns = [{
        headerName: "Business Date",
        field: "date",
        filter: false,
        cellRenderer: "",
      }];

      data[0].platform.forEach((item: any) => {
        columns.push({
          headerName: item.country,
          field: item.country,
          filter: true,
          cellRenderer: item.value < 0 ? "agGroupCellRenderer" : "",

        });
      });

      setColumns(columns);

      const rowData = data.map((item: any) => {
        const row = {
          "date": item.date,
        };
        let hasNegative = false;

        item.platform.forEach((platform: any) => {
          row[platform.country] = platform.value;
          if(platform.value < 0) hasNegative = true;
        });
        if(hasNegative) {
          row["children"] = [
            {
              a2: "level 2 - 333",
              b2: "level 2 - 444",
            },
          ];
        }

        return row;
      });
      setRowData(rowData);

    }
  }, [data, error, isLoading]);

  return (
    <section className='flex flex-col h-[700px]'>
      <AgGrid columns={columns} rowData={rowData} />
    </section>
  );
};

export default UnBalanced;