
import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';

const initialState = {
  filterType: '1W',
  currency: 'USD',
};

export const headerSlice = createSlice({
  name: 'header',
  initialState,
  reducers: {
    setFilterType: (state, action: PayloadAction<string>) => {
      state.filterType = action.payload;
    },
    setCurrency: (state, action: PayloadAction<string>) => {
      state.currency = action.payload;
    },
  },
})

export const { setFilterType, setCurrency } = headerSlice.actions;

export default headerSlice.reducer;