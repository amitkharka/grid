import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export const unbalancedApi = createApi({
  reducerPath: 'unbalancedApi',
  baseQuery: fetchBaseQuery({ baseUrl: '/' }),
  endpoints: (builder) => ({
    getUnbalancedData: builder.query({
      query: (filters) => {
        console.log(filters);
        return 'src/__mocks__/unbalanced-response.json';
      }
    }),
  }),
})

export const { useGetUnbalancedDataQuery } = unbalancedApi;