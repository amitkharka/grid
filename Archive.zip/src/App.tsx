import TableHeader from './components/TableHeader/TableHeader';
import RouterConfig from './routes/RouterConfig';
import { AllCommunityModule, ClientSideRowModelModule, ModuleRegistry, ValidationModule } from 'ag-grid-community'; 
import { ColumnMenuModule, ColumnsToolPanelModule, ContextMenuModule, ExcelExportModule, MasterDetailModule } from 'ag-grid-enterprise'; 

// Register all Community features
ModuleRegistry.registerModules([
  ExcelExportModule,
  AllCommunityModule,
  ClientSideRowModelModule,
  ColumnsToolPanelModule,
  MasterDetailModule,
  ColumnMenuModule,
  ContextMenuModule,
  ValidationModule /* Development Only */,
]);


function App() {
  return (
    <main className='p-4'>
      <TableHeader />
      <RouterConfig />
    </main>
  )
}

export default App;
