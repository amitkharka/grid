import { Navigate } from "react-router";
import Balanced from "../pages/Balanced";
import Unbalanced from "../pages/Unbalanced";
import { Routes, Route } from "react-router";

const routes = [
  {
    path: "/unbalanced",
    component: Unbalanced,
  },
  {
    path: "/balanced",
    component: Balanced,
  }
];

const RouterConfig = () => (
  <Routes>
    <Route path="/" element={<Navigate to="/unbalanced" replace />} />
    {
      routes.map((route, index) => (
        <Route key={index} path={route.path} element={<route.component />} />
      ))
    }
  </Routes>
);

export default RouterConfig;